$> npm init
This utility will walk you through creating a package.json file.
It only covers the most common items, and tries to guess sensible defaults.

See `npm help json` for definitive documentation on these fields
and exactly what they do.

Use `npm install <pkg>` afterwards to install a package and
save it as a dependency in the package.json file.

Press ^C at any time to quit.
package name: (hello-erc20-kata) 
version: (1.0.0) 
description: My implementation of the Hello ERC20 token kata.
entry point: (truffle-config.js) 
test command: truffle test
git repository: (https://github.com/electronicpanopticon/hello-erc20-kata.git) 
keywords: truffle solidity ethereum tdd
author: Christoph
license: (ISC) MIT
About to write to /Users/christoph/tmp/hello-erc20-kata/package.json:

{
  "name": "hello-erc20-kata",
  "version": "1.0.0",
  "description": "My implementation of the Hello ERC20 token kata.",
  "main": "truffle-config.js",
  "directories": {
    "test": "test"
  },
  "scripts": {
    "test": "truffle test"
  },
  "repository": {
    "type": "git",
    "url": "git+https://github.com/electronicpanopticon/hello-erc20-kata.git"
  },
  "keywords": [
    "truffle",
    "solidity",
    "ethereum",
    "tdd"
  ],
  "author": "Christoph",
  "license": "MIT",
  "bugs": {
    "url": "https://github.com/electronicpanopticon/hello-erc20-kata/issues"
  },
  "homepage": "https://github.com/electronicpanopticon/hello-erc20-kata#readme"
}


Is this ok? (yes) 
✔ ~/tmp/hello-erc20-kata [mysolution|…5] 
$>